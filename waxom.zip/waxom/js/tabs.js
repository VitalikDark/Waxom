$(".wrapper_tab .tab").click(function() {
  $(".wrapper_tab .tab").removeClass("active").eq($(this).index()).addClass("active");
  $(".tab_item").hide().eq($(this).index()).fadeIn(800)
}).eq(0).addClass("active");