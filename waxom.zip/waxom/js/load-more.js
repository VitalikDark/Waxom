var more=document.getElementById("load_more");
var load_content=document.getElementById('load_content');


more.addEventListener("click", function() {
	load_content.style.display = 'block';
	more.style.display='none';

	console.log('load');
});